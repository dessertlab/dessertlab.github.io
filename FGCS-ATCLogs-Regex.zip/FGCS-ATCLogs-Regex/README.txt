This archive FGCS-ATCLogs-Regex.zip accompanies the submission of the manuscript:

Contextual filtering and prioritization of computer application logs for security situational awareness

co-authored by

Marcello Cinque*, Raffaele Della Corte*, and Antonio Pecchia**
*Università degli Studi di Napoli Federico II
**Università degli Studi del Sannio

and submitted for evaluation to FUTURE GENERATION COMPUTER SYSTEMS.


CONTENT:

This archive is provided to researchers, who wish to have a deep look into the regular expressions used in our study as well as for replication purposes. 

The archive contains the following items:
- README.txt: This file;
- Regex.txt: Containing the list of regular expressions used in our Air Traffic Control case study.

 
CONTACT:

For any further information please contact the Authors:

macinque@unina.it
raffaele.dellacorte2@unina.it
antonio.pecchia@unisannio.it
