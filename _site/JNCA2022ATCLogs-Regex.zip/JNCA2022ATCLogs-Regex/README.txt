This archive JNCA2022ATCLogs-Regex.zip accompanies the submission of the manuscript:

Micro2vec: Anomaly Detection in Microservices Systems by Mining Numeric Representations of Computer Logs

co-authored by

Marcello Cinque*, Raffaele Della Corte*, and Antonio Pecchia**
*Università degli Studi di Napoli Federico II
**Università degli Studi del Sannio

and submitted for evaluation to JOURNAL OF NETWORK AND COMPUTER APPLICATIONS.


CONTENT:

This archive is provided to researchers, who wish to have a deep look into the regular expressions used in our study as well as for replication purposes. 

The archive contains the following items:
- README.txt: This file;
- Regex.txt: Containing the list of regular expressions used in our Air Traffic Control case study.

 
CONTACT:

For any further information please contact the Authors:

macinque@unina.it
raffaele.dellacorte2@unina.it
antonio.pecchia@unisannio.it
